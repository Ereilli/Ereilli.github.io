import pygame
import sys

pygame.init()

# screen settings
WIDTH, HEIGHT = 640, 480
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Solo Pong")

# colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# paddle settings
paddle_width, paddle_height = 10, 60
paddle_x, paddle_y = 30, HEIGHT // 2 - paddle_height // 2
paddle_speed = 5

# ball settings
ball_size = 15
ball_x, ball_y = WIDTH // 2, HEIGHT // 2
ball_speed_x = 4
ball_speed_y = 4

# score
score = 0

clock = pygame.time.Clock()

running = True
while running:
    clock.tick(60)  # 60 fps
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # move paddle
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and paddle_y > 0:
        paddle_y -= paddle_speed
    if keys[pygame.K_s] and paddle_y < HEIGHT - paddle_height:
        paddle_y += paddle_speed

    # move ball
    ball_x += ball_speed_x
    ball_y += ball_speed_y

    # ball collision with top and bottom
    if ball_y <= 0 or ball_y >= HEIGHT - ball_size:
        ball_speed_y = -ball_speed_y

    # ball collision with right wall
    if ball_x >= WIDTH - ball_size:
        ball_speed_x = -ball_speed_x

    # ball collision with paddle
    if (
        ball_x <= paddle_x + paddle_width
        and paddle_y < ball_y + ball_size
        and ball_y < paddle_y + paddle_height
    ):
        ball_speed_x = -ball_speed_x
        score += 1

    # ball missed paddle
    if ball_x < 0:
        running = False

    # clear screen
    screen.fill(BLACK)

    # draw paddle
    pygame.draw.rect(screen, WHITE, (paddle_x, paddle_y, paddle_width, paddle_height))

    # draw ball
    pygame.draw.rect(screen, WHITE, (ball_x, ball_y, ball_size, ball_size))

    # draw score
    font = pygame.font.Font(None, 36)
    text = font.render(f"score: {score}", True, WHITE)
    screen.blit(text, (10, 10))

    pygame.display.flip()

pygame.quit()
sys.exit()
