from collections import Counter

# text file path
file_path = input("Enter the path to a .txt file: ")

try:
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
except FileNotFoundError:
    print("File not found. Make sure the path is correct.")
    exit()

# basic statistics
total_lines = text.count('\n') + 1
total_words = len(text.split())
total_chars_with_spaces = len(text)
total_chars_no_spaces = len(text.replace(" ", "").replace("\n", ""))
letter_e_count = text.lower().count('e')

# word frequency
words = text.lower().split()
word_counts = Counter(words)
most_common_words = word_counts.most_common(5)

# results
print("\n--- Text File Analysis ---")
print(f"Total lines: {total_lines}")
print(f"Total words: {total_words}")
print(f"Total characters (with spaces): {total_chars_with_spaces}")
print(f"Total characters (without spaces): {total_chars_no_spaces}")
print(f"Total occurrences of the letter 'E': {letter_e_count}")
print("\nTop 5 most common words:")
for word, count in most_common_words:
    print(f"{word}: {count}")
