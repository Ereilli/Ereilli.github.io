import pygame
import time
import random

pygame.init()

# colours
white = (255, 255, 255)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)
blue = (50, 153, 213)

# display
width = 600
height = 400
dis = pygame.display.set_mode((width, height))
pygame.display.set_caption('Snake Game')

# snake settings
snake_block = 10
snake_speed = 15
clock = pygame.time.Clock()

font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)

def score_display(score):
    value = score_font.render("Score: " + str(score), True, white)
    dis.blit(value, [0, 0])

def draw_snake(block, snake_list):
    for x in snake_list:
        pygame.draw.rect(dis, green, [x[0], x[1], block, block])

def message(msg_lines, color):
    for i, line in enumerate(msg_lines):
        mesg = font_style.render(line, True, color)
        text_rect = mesg.get_rect(center=(width / 2, height / 3 + i * 30))
        dis.blit(mesg, text_rect)

def game_loop():
    game_over = False
    game_close = False

    x1 = width / 2
    y1 = height / 2
    x1_change = 0
    y1_change = 0

    snake_list = []
    length_of_snake = 1

    foodx = round(random.randrange(0, width - snake_block) / 10.0) * 10.0
    foody = round(random.randrange(0, height - snake_block) / 10.0) * 10.0

    while not game_over:

        while game_close:
            dis.fill(black)
            message(["You lose, Mr.Snake is dead :c", "Press C-Play Again or Q-Quit"], white)
            score_display(length_of_snake - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        game_loop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:  # Left
                    x1_change = -snake_block
                    y1_change = 0
                elif event.key == pygame.K_d:  # Right
                    x1_change = snake_block
                    y1_change = 0
                elif event.key == pygame.K_w:  # Up
                    y1_change = -snake_block
                    x1_change = 0
                elif event.key == pygame.K_s:  # Down
                    y1_change = snake_block
                    x1_change = 0


        x1 += x1_change
        y1 += y1_change
        if x1 >= width or x1 < 0 or y1 >= height or y1 < 0:
            game_close = True
        dis.fill(black)
        pygame.draw.rect(dis, red, [foodx, foody, snake_block, snake_block])
        snake_head = []
        snake_head.append(x1)
        snake_head.append(y1)
        snake_list.append(snake_head)
        if len(snake_list) > length_of_snake:
            del snake_list[0]

        for x in snake_list[:-1]:
            if x == snake_head:
                game_close = True

        draw_snake(snake_block, snake_list)
        score_display(length_of_snake - 1)
        pygame.display.update()

        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, width - snake_block) / 10.0) * 10.0
            foody = round(random.randrange(0, height - snake_block) / 10.0) * 10.0
            length_of_snake += 1

        clock.tick(snake_speed)

    pygame.quit()
    quit()

game_loop()
